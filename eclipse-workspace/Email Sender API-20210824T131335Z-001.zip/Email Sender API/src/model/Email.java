package model;

public class Email {

}
