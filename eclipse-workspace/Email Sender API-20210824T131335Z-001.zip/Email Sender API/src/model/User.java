package model;

import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;

import model.data.DataHandler;
import model.data.Pair;
import model.emailSender.EmailSender;

public class User implements EmailSender, DataHandler {

	/***
	 * User duhet te kete kredenciale
	 * ne nje server qe ofron sherbime
	 * per dergim email-i (nese do behet sherbim me db).
	 * User duhet te kete kredenciale
	 * per t'u lidhur me nje server
	 * ku do ruaj te dhena per te gjithe
	 * mesazhet qe dergohen.
	 * User ne database/file mund te ruaje 
	 * dhe lexoje te dhenat e klienteve.
	 * 
	 * */
	
	
	@Override
	public boolean send(Email to, String text) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean send(Email to, Email bcc, String text) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean send(Email to, Email bcc, Email cc, String text) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean send(Set<Email> to, Set<Email> bcc, Set<Email> cc, String text) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void saveText(Email email, String text, GregorianCalendar date) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Pair<GregorianCalendar, String>> getText(Email email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Client getClientData(Email email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existClient(Client clientData) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void addClient(Client clientData) {
		// TODO Auto-generated method stub
		
	}

}
