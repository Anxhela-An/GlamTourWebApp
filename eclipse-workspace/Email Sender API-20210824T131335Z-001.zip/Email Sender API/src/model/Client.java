package model;

public class Client {

	/**
	 *	ka emaile
	 **/
	
}
