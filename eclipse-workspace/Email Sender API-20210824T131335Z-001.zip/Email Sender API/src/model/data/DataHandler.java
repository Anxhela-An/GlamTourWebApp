package model.data;

import java.util.GregorianCalendar;
import java.util.List;

import model.Client;
import model.Email;

public interface DataHandler {

	void saveText(Email email, String text,
				  GregorianCalendar date);
	List <Pair<GregorianCalendar, String>> 
			getText(Email email);
	
	Client getClientData(Email email);
	boolean existClient(Client clientData);
	void addClient(Client clientData);
		 
}
