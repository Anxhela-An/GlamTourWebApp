package model.data;

public interface FileHandler extends DataHandler {
  
}
