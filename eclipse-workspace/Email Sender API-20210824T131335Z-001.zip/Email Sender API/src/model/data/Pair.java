package model.data;

public class Pair<T1, T2> {

	private T1 member1;
	private T2 member2;
	
}
