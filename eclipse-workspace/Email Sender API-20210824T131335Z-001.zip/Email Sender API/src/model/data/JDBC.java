package model.data;

import java.sql.Connection;
import java.sql.ResultSet;

public interface JDBC extends DataHandler {

	boolean connect(String serverName,
				    String databaseName,
				    String username,
				    String password);
	Connection getConnection();
	ResultSet executeQuery(String query);
	boolean executeUpdate(String query);
	 
}
