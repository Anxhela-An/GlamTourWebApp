package model.emailSender;

import java.util.List;
import java.util.Set;

import model.Email;

public interface EmailSender {

	boolean send(Email to, String text);
	boolean send(Email to, Email bcc, String text);
	boolean send(Email to, Email bcc, 
				 Email cc, String text);
	boolean send(Set<Email> to, Set<Email> bcc, 
			 	 Set<Email> cc, String text);
	
	default boolean send(Set<Email> to, 
						 Set<Email> bcc, 
						 Set<Email> cc, 
						 List<String> text) {
		boolean status = true;
		for(String txt : text) {
			if(!send(to, bcc, cc, txt)) {
				status = false;
			}
		}
		return status;
	}
	
}
